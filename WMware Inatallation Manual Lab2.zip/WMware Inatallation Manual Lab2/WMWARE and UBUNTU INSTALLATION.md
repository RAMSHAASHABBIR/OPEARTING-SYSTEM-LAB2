# **Installation of VMware and Ubuntu**



#### Ramsha Shabbir                                                                                           2022-CS-205



Here is the step by step installation of VMware and ubuntu.

- Search VMware workstation player and select download.

![](E:\WMware and Ubuntu inatallation\Screenshot (138).png)



- Download workstation player 17 for windows.

![](E:\WMware and Ubuntu inatallation\Screenshot (139).png)

-  Now download ubuntu desktop latest version.

- ![](E:\WMware and Ubuntu inatallation\Screenshot (141).png)

- Click download 22.04.3.

![](E:\WMware and Ubuntu inatallation\Screenshot (142).png)

- Open VMware exe.

![](E:\WMware and Ubuntu inatallation\Screenshot (143).png)

- Click Next.

![](E:\WMware and Ubuntu inatallation\Screenshot (145).png)

- Click next.

![](E:\WMware and Ubuntu inatallation\Screenshot (146).png)

- Click next

![](E:\WMware and Ubuntu inatallation\Screenshot (147).png)

- Click next.

![](E:\WMware and Ubuntu inatallation\Screenshot (148).png)

- Click install.

![](E:\WMware and Ubuntu inatallation\Screenshot (149).png)

- After installing click next.

![](E:\WMware and Ubuntu inatallation\Screenshot (150).png)

- Click finish.

![](E:\WMware and Ubuntu inatallation\Screenshot (151).png)

- Click Continue.

![](E:\WMware and Ubuntu inatallation\Screenshot (152).png)

- Open VMware and create new virtual machine.

![](E:\WMware and Ubuntu inatallation\Screenshot (153).png)

- Click Browse and select ubuntu file.

![](E:\WMware and Ubuntu inatallation\Screenshot (154).png)

- Click open.

![](E:\WMware and Ubuntu inatallation\Screenshot (156).png)

- Click Next.

![](E:\WMware and Ubuntu inatallation\Screenshot (157).png)

- Now fill this field and click Next.

![](E:\WMware and Ubuntu inatallation\Screenshot (158).png)

- Click Next.

![](E:\WMware and Ubuntu inatallation\Screenshot (159).png)

- Click Next.

![](E:\WMware and Ubuntu inatallation\Screenshot (161).png)

- Click finish .

![](E:\WMware and Ubuntu inatallation\Screenshot (162).png)

- Wait for it to open.

![](E:\WMware and Ubuntu inatallation\Screenshot (164).png)

- Wait for it to install.

![](E:\WMware and Ubuntu inatallation\Screenshot (165).png)

- Click Continue.

![](E:\WMware and Ubuntu inatallation\Screenshot (166).png)

- Click Continue.

![](E:\WMware and Ubuntu inatallation\Screenshot (167).png)

- Click install now.

![](E:\WMware and Ubuntu inatallation\Screenshot (168).png)

- Wait for few minutes.

![](E:\WMware and Ubuntu inatallation\Screenshot (169).png)

- Now restart your pc.

![](E:\WMware and Ubuntu inatallation\Screenshot (170).png)

- Enter password.

![](E:\WMware and Ubuntu inatallation\Screenshot (171).png)

- Now perform task you want.

![](E:\WMware and Ubuntu inatallation\Screenshot (172).png)
